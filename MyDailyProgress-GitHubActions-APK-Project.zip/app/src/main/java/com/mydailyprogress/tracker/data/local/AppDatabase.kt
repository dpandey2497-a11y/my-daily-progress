package com.mydailyprogress.tracker.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Database(
    entities = [
        HabitEntity::class,
        HabitLogEntity::class,
        StudySessionEntity::class,
        FitnessLogEntity::class,
        JournalEntity::class,
        PersonalGoalEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "my_daily_progress.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            seedDefaultHabits(getInstance(context).appDao())
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun seedDefaultHabits(dao: AppDao) {
            if (dao.getHabitCount() > 0) return
            val todayEpoch = LocalDate.now().toEpochDay()
            val defaults = listOf(
                HabitEntity(titleEn = "Wake up early", titleHi = "सुबह जल्दी उठना", category = "Routine", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "05:00", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Morning exercise", titleHi = "सुबह का व्यायाम", category = "Fitness", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "05:45", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Yoga and meditation", titleHi = "योग और ध्यान", category = "Mindfulness", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "06:30", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Reading books", titleHi = "किताबें पढ़ना", category = "Study", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "08:00", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Study", titleHi = "अध्ययन करना", category = "Study", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "09:00", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Drink sufficient water", titleHi = "पर्याप्त पानी पीना", category = "Health", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "11:00", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Healthy eating", titleHi = "पौष्टिक आहार लेना", category = "Health", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "13:00", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Avoid mobile distractions", titleHi = "मोबाइल भटकाव से बचना", category = "Discipline", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "15:00", createdAtEpochDay = todayEpoch),
                HabitEntity(titleEn = "Sleep on time", titleHi = "समय पर सोना", category = "Routine", scheduleType = "DAILY", customDaysCsv = "0,1,2,3,4,5,6", reminderTime = "22:15", createdAtEpochDay = todayEpoch)
            )
            defaults.forEach { dao.upsertHabit(it) }
        }
    }
}
