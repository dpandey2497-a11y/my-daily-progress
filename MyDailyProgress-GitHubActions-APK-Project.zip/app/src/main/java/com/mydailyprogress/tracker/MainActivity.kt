package com.mydailyprogress.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mydailyprogress.tracker.ui.screens.*
import com.mydailyprogress.tracker.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            val prefs by vm.preferences.collectAsState()
            val colorScheme = if (prefs.isDarkMode) darkColorScheme() else lightColorScheme()

            MaterialTheme(colorScheme = colorScheme) {
                MyDailyProgressApp(vm = vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyDailyProgressApp(vm: MainViewModel) {
    var currentTab by remember { mutableStateOf("home") }
    val prefs by vm.preferences.collectAsState()
    val isHi = prefs.languageCode == "hi"

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (isHi) "मेरी दैनिक प्रगति" else "My Daily Progress")
                },
                actions = {
                    TextButton(onClick = { vm.setLanguage(if (isHi) "en" else "hi") }) {
                        Text(if (isHi) "EN" else "हिंदी")
                    }
                    IconButton(onClick = { currentTab = "settings" }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == "home",
                    onClick = { currentTab = "home" },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text(if (isHi) "होम" else "Home") }
                )
                NavigationBarItem(
                    selected = currentTab == "habits",
                    onClick = { currentTab = "habits" },
                    icon = { Icon(Icons.Default.CheckCircle, contentDescription = null) },
                    label = { Text(if (isHi) "आदतें" else "Habits") }
                )
                NavigationBarItem(
                    selected = currentTab == "study",
                    onClick = { currentTab = "study" },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
                    label = { Text(if (isHi) "अध्ययन" else "Study") }
                )
                NavigationBarItem(
                    selected = currentTab == "fitness",
                    onClick = { currentTab = "fitness" },
                    icon = { Icon(Icons.Default.FitnessCenter, contentDescription = null) },
                    label = { Text(if (isHi) "फिटनेस" else "Fitness") }
                )
                NavigationBarItem(
                    selected = currentTab == "reports",
                    onClick = { currentTab = "reports" },
                    icon = { Icon(Icons.Default.Assessment, contentDescription = null) },
                    label = { Text(if (isHi) "रिपोर्ट्स" else "Reports") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when (currentTab) {
                "home" -> DashboardScreen(vm)
                "habits" -> HabitsScreen(vm)
                "study" -> StudyScreen(vm)
                "fitness" -> FitnessScreen(vm)
                "reports" -> ReportsScreen(vm)
                "settings" -> SettingsScreen(vm)
                else -> DashboardScreen(vm)
            }
        }
    }
}
