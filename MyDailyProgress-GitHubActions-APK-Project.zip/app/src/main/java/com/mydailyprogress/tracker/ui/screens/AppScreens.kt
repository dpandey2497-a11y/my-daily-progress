package com.mydailyprogress.tracker.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mydailyprogress.tracker.data.local.*
import com.mydailyprogress.tracker.notifications.ReminderReceiver
import com.mydailyprogress.tracker.viewmodel.MainViewModel
import kotlinx.coroutines.delay
import java.time.LocalDate

@Composable
fun DashboardScreen(vm: MainViewModel) {
    val habits by vm.habits.collectAsState()
    val logs by vm.habitLogs.collectAsState()
    val prefs by vm.preferences.collectAsState()
    val isHi = prefs.languageCode == "hi"
    val todayStr = LocalDate.now().toString()

    val todayLogs = logs.filter { it.dateStr == todayStr }.associateBy { it.habitId }
    val total = habits.size
    val completed = habits.count { todayLogs[it.id]?.status == "COMPLETED" }
    val pending = (total - completed).coerceAtLeast(0)
    val pct = if (total > 0) (completed * 100) / total else 0

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHi) "आज की प्रगति ($todayStr)" else "Today's Progress ($todayStr)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { pct / 100f },
                        modifier = Modifier.fillMaxWidth().height(10.dp),
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (isHi) "पूर्ण: $completed/$total ($pct%)" else "Completed: $completed/$total ($pct%)")
                        Text(if (isHi) "बाकी: $pending" else "Pending: $pending")
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHi) "आज का प्रेरक विचार" else "Daily Motivational Quote",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isHi)
                            "“प्रतिदिन के छोटे और अनुशासित प्रयास ही असाधारण सफलता का निर्माण करते हैं।” — स्वामी विवेकानंद"
                        else
                            "“Small disciplined daily actions build extraordinary character and success.” — Swami Vivekananda",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        item {
            Text(
                text = if (isHi) "आज की आदतों की सूची (टैप करके पूरा करें)" else "Today's Habit Checklist (Tap to toggle)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(habits) { habit ->
            val status = todayLogs[habit.id]?.status
            OutlinedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.toggleHabitStatus(habit.id, todayStr, status) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHi) habit.titleHi else habit.titleEn,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${habit.category} · ${habit.reminderTime}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Text(
                        text = when (status) {
                            "COMPLETED" -> if (isHi) "✓ पूर्ण" else "✓ Done"
                            "MISSED" -> if (isHi) "✗ छूटी" else "✗ Missed"
                            else -> if (isHi) "बाकी" else "Pending"
                        },
                        color = when (status) {
                            "COMPLETED" -> MaterialTheme.colorScheme.primary
                            "MISSED" -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.outline
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun HabitsScreen(vm: MainViewModel) {
    val habits by vm.habits.collectAsState()
    val prefs by vm.preferences.collectAsState()
    val isHi = prefs.languageCode == "hi"

    var newTitleEn by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Routine") }
    var newTime by remember { mutableStateOf("06:00") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isHi) "नई आदत जोड़ें" else "Add New Habit",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(
                        value = newTitleEn,
                        onValueChange = { newTitleEn = it },
                        label = { Text(if (isHi) "आदत का नाम" else "Habit Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newCategory,
                            onValueChange = { newCategory = it },
                            label = { Text(if (isHi) "श्रेणी" else "Category") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newTime,
                            onValueChange = { newTime = it },
                            label = { Text(if (isHi) "समय (HH:mm)" else "Reminder (HH:mm)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Button(
                        onClick = {
                            if (newTitleEn.isNotBlank()) {
                                vm.saveHabit(newTitleEn.trim(), newTitleEn.trim(), newCategory, "DAILY", newTime)
                                newTitleEn = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isHi) "आदत सहेजें" else "Save Habit")
                    }
                }
            }
        }

        items(habits) { habit ->
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHi) habit.titleHi else habit.titleEn,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${habit.category} · ${habit.scheduleType} · ${habit.reminderTime}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    IconButton(onClick = { vm.deleteHabit(habit) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun StudyScreen(vm: MainViewModel) {
    val sessions by vm.studySessions.collectAsState()
    val prefs by vm.preferences.collectAsState()
    val isHi = prefs.languageCode == "hi"

    val subjects = listOf(
        "History", "Geography", "Polity", "Economy",
        "Science", "Environment", "Current Affairs", "Optional Subject"
    )
    var selectedSubject by remember { mutableStateOf(subjects[0]) }
    var notes by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var seconds by remember { mutableStateOf(0) }

    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            seconds++
        }
    }

    val totalMinutes = sessions.sumOf { it.durationMinutes }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = prefs.activeExam == "UPSC",
                    onClick = { vm.setActiveExam("UPSC") },
                    label = { Text("UPSC CSE Goal (8h/day)") }
                )
                FilterChip(
                    selected = prefs.activeExam == "BPSC",
                    onClick = { vm.setActiveExam("BPSC") },
                    label = { Text("BPSC CCE Goal (7h/day)") }
                )
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${prefs.activeExam} · $selectedSubject",
                        style = MaterialTheme.typography.labelLarge
                    )
                    val h = seconds / 3600
                    val m = (seconds % 3600) / 60
                    val s = seconds % 60
                    Text(
                        text = String.format("%02d:%02d:%02d", h, m, s),
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(if (isHi) "अध्ययन नोट्स (Notes)" else "Session Topic & Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { running = !running }) {
                            Text(if (running) (if (isHi) "रोकें" else "Pause") else (if (isHi) "प्रारंभ करें" else "Start Timer"))
                        }
                        OutlinedButton(onClick = { seconds += 1800 }) {
                            Text("+30m")
                        }
                        Button(
                            onClick = {
                                val mins = (seconds / 60).coerceAtLeast(15)
                                vm.logStudySession(
                                    exam = prefs.activeExam,
                                    subject = selectedSubject,
                                    durationMinutes = mins,
                                    notes = notes.ifBlank { "$selectedSubject focused study block" }
                                )
                                running = false
                                seconds = 0
                                notes = ""
                            }
                        ) {
                            Text(if (isHi) "सत्र सहेजें" else "Save Log")
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = if (isHi) "विषय चुनें (8 मुख्य विषय)" else "Select Subject (8 Core Subjects)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                subjects.take(4).forEach { subj ->
                    FilterChip(
                        selected = selectedSubject == subj,
                        onClick = { selectedSubject = subj },
                        label = { Text(subj) }
                    )
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                subjects.drop(4).forEach { subj ->
                    FilterChip(
                        selected = selectedSubject == subj,
                        onClick = { selectedSubject = subj },
                        label = { Text(subj.take(10)) }
                    )
                }
            }
        }

        item {
            Text(
                text = if (isHi) "कुल अध्ययन: ${totalMinutes / 60} घंटे ${totalMinutes % 60} मिनट" else "Total Focused Study: ${totalMinutes / 60}h ${totalMinutes % 60}m",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(sessions) { session ->
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "${session.examType} · ${session.subject} · ${session.durationMinutes} mins (${session.dateStr})",
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = session.notes, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
fun FitnessScreen(vm: MainViewModel) {
    val fitnessLogs by vm.fitnessLogs.collectAsState()
    val prefs by vm.preferences.collectAsState()
    val isHi = prefs.languageCode == "hi"
    val todayLog = fitnessLogs.lastOrNull()

    var weightText by remember(todayLog) { mutableStateOf((todayLog?.bodyWeightKg ?: 57.5f).toString()) }
    var targetText by remember(prefs.targetWeightKg) { mutableStateOf(prefs.targetWeightKg.toString()) }
    var proteinGrams by remember(todayLog) { mutableStateOf(todayLog?.proteinGrams ?: 85) }
    var waterMl by remember(todayLog) { mutableStateOf(todayLog?.waterMl ?: 2250) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isHi) "शरीर का वजन और 60 किग्रा मसल गेन लक्ष्य" else "Body Weight & 60 kg Muscle Gain Goal",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = weightText,
                            onValueChange = { weightText = it },
                            label = { Text(if (isHi) "आज का वजन (kg)" else "Current Weight (kg)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = targetText,
                            onValueChange = { targetText = it },
                            label = { Text(if (isHi) "लक्ष्य वजन (kg)" else "Target Weight (kg)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isHi) "पानी: $waterMl ml / 3000 ml" else "Water: $waterMl ml / 3000 ml")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { waterMl += 250 }) { Text("+250ml") }
                            OutlinedButton(onClick = { proteinGrams += 15 }) { Text("+15g Protein ($proteinGrams g)") }
                        }
                    }
                    Button(
                        onClick = {
                            val w = weightText.toFloatOrNull() ?: 57.5f
                            val t = targetText.toFloatOrNull() ?: 60.0f
                            vm.setTargetWeight(t)
                            vm.saveDailyFitness(w, "Pushups,Squats,Pullups,Plank,SuryaNamaskar", proteinGrams, waterMl, "Consistent workout")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isHi) "आज का फिटनेस डेटा सहेजें" else "Save Today's Weight, Diet & Water")
                    }
                }
            }
        }

        items(fitnessLogs.reversed()) { log ->
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "${log.dateStr} — Weight: ${log.bodyWeightKg} kg (Target: ${prefs.targetWeightKg} kg)",
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = "Protein: ${log.proteinGrams}g · Water: ${log.waterMl}ml · Workouts: ${log.completedWorkoutsCsv}")
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(vm: MainViewModel) {
    val habits by vm.habits.collectAsState()
    val logs by vm.habitLogs.collectAsState()
    val study by vm.studySessions.collectAsState()
    val prefs by vm.preferences.collectAsState()
    val isHi = prefs.languageCode == "hi"

    val completedTotal = logs.count { it.status == "COMPLETED" }
    val missedTotal = logs.count { it.status == "MISSED" }
    val studyHours = study.sumOf { it.durationMinutes } / 60f

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isHi) "मासिक कैलेंडर और निरंतरता रिपोर्ट" else "Monthly Consistency & Reports",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(if (isHi) "✓ पूर्ण आदतें (हरा चिह्न): $completedTotal" else "✓ Completed Habits (Green Mark): $completedTotal")
                    Text(if (isHi) "✗ छूटी हुई आदतें (लाल चिह्न): $missedTotal" else "✗ Missed Habits (Red Mark): $missedTotal")
                    Text(if (isHi) "कुल केंद्रित अध्ययन घंटे: ${String.format(\"%.1f\", studyHours)} hrs" else "Total Focused Study Hours: ${String.format(\"%.1f\", studyHours)} hrs")
                    Text(if (isHi) "कुल सक्रिय आदतें: ${habits.size}" else "Total Active Habits: ${habits.size}")
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val prefs by vm.preferences.collectAsState()
    val isHi = prefs.languageCode == "hi"
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (isHi) "ऐप सेटिंग्स और रिमाइंडर" else "App Settings & Offline Notifications",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isHi) "डार्क मोड (Dark Mode)" else "Dark Mode")
                        Switch(checked = prefs.isDarkMode, onCheckedChange = { vm.setDarkMode(it) })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isHi) "भाषा: हिंदी / English" else "Language: English / हिंदी")
                        Button(onClick = { vm.setLanguage(if (isHi) "en" else "hi") }) {
                            Text(if (isHi) "Switch to English" else "हिंदी में बदलें")
                        }
                    }
                    Button(
                        onClick = {
                            val intent = Intent(context, ReminderReceiver::class.java).apply {
                                putExtra("EXTRA_TITLE", "My Daily Progress")
                                putExtra("EXTRA_MESSAGE", "Offline notification test succeeded!")
                            }
                            context.sendBroadcast(intent)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isHi) "टेस्ट नोटिफिकेशन भेजें" else "Send Test Local Notification")
                    }
                    OutlinedButton(
                        onClick = { vm.resetStatistics() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isHi) "आँकड़े रीसेट करें (Reset Stats)" else "Reset Habit Statistics")
                    }
                }
            }
        }
    }
}
