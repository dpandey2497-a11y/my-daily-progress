package com.mydailyprogress.tracker.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_settings")

data class UserPreferences(
    val isDarkMode: Boolean = false,
    val languageCode: String = "en",
    val targetWeightKg: Float = 60.0f,
    val upscDailyTargetHours: Int = 8,
    val bpscDailyTargetHours: Int = 7,
    val dailyWaterGoalMl: Int = 3000,
    val dailyProteinGoalG: Int = 110,
    val activeExam: String = "UPSC"
)

class SettingsDataStore(private val context: Context) {
    companion object {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val LANGUAGE = stringPreferencesKey("language_code")
        val TARGET_WEIGHT = floatPreferencesKey("target_weight_kg")
        val UPSC_TARGET_HOURS = intPreferencesKey("upsc_target_hours")
        val BPSC_TARGET_HOURS = intPreferencesKey("bpsc_target_hours")
        val ACTIVE_EXAM = stringPreferencesKey("active_exam")
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            isDarkMode = prefs[DARK_MODE] ?: false,
            languageCode = prefs[LANGUAGE] ?: "en",
            targetWeightKg = prefs[TARGET_WEIGHT] ?: 60.0f,
            upscDailyTargetHours = prefs[UPSC_TARGET_HOURS] ?: 8,
            bpscDailyTargetHours = prefs[BPSC_TARGET_HOURS] ?: 7,
            activeExam = prefs[ACTIVE_EXAM] ?: "UPSC"
        )
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[DARK_MODE] = enabled }
    }

    suspend fun setLanguage(code: String) {
        context.dataStore.edit { it[LANGUAGE] = code }
    }

    suspend fun setTargetWeight(weightKg: Float) {
        context.dataStore.edit { it[TARGET_WEIGHT] = weightKg }
    }

    suspend fun setActiveExam(exam: String) {
        context.dataStore.edit { it[ACTIVE_EXAM] = exam }
    }
}
