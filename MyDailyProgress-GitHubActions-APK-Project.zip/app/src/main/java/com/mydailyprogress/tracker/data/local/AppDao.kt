package com.mydailyprogress.tracker.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM habits ORDER BY id ASC")
    fun observeHabits(): Flow<List<HabitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHabit(habit: HabitEntity): Long

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("SELECT COUNT(*) FROM habits")
    suspend fun getHabitCount(): Int

    @Query("SELECT * FROM habit_logs")
    fun observeAllHabitLogs(): Flow<List<HabitLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHabitLog(log: HabitLogEntity)

    @Query("DELETE FROM habit_logs WHERE habitId = :habitId AND dateStr = :dateStr")
    suspend fun deleteHabitLog(habitId: Long, dateStr: String)

    @Query("DELETE FROM habit_logs")
    suspend fun clearAllHabitLogs()

    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    fun observeStudySessions(): Flow<List<StudySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudySession(session: StudySessionEntity)

    @Delete
    suspend fun deleteStudySession(session: StudySessionEntity)

    @Query("SELECT * FROM fitness_logs ORDER BY dateStr ASC")
    fun observeFitnessLogs(): Flow<List<FitnessLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFitnessLog(log: FitnessLogEntity)

    @Query("SELECT * FROM journal_entries ORDER BY dateStr DESC")
    fun observeJournals(): Flow<List<JournalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJournal(journal: JournalEntity)

    @Query("SELECT * FROM personal_goals ORDER BY id DESC")
    fun observeGoals(): Flow<List<PersonalGoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGoal(goal: PersonalGoalEntity)

    @Delete
    suspend fun deleteGoal(goal: PersonalGoalEntity)
}
