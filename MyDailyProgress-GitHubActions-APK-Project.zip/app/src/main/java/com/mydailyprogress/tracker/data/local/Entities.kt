package com.mydailyprogress.tracker.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titleEn: String,
    val titleHi: String,
    val category: String,
    val scheduleType: String,
    val customDaysCsv: String,
    val reminderTime: String,
    val reminderEnabled: Boolean = true,
    val createdAtEpochDay: Long
)

@Entity(tableName = "habit_logs", primaryKeys = ["habitId", "dateStr"])
data class HabitLogEntity(
    val habitId: Long,
    val dateStr: String,
    val status: String // "COMPLETED" or "MISSED"
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateStr: String,
    val examType: String, // "UPSC" or "BPSC"
    val subject: String,
    val durationMinutes: Int,
    val notes: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "fitness_logs")
data class FitnessLogEntity(
    @PrimaryKey val dateStr: String,
    val bodyWeightKg: Float,
    val completedWorkoutsCsv: String,
    val proteinGrams: Int,
    val waterMl: Int,
    val notes: String
)

@Entity(tableName = "journal_entries")
data class JournalEntity(
    @PrimaryKey val dateStr: String,
    val mood: String,
    val content: String,
    val gratitude: String
)

@Entity(tableName = "personal_goals")
data class PersonalGoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val targetDate: String,
    val progressPercent: Int,
    val isCompleted: Boolean
)
