package com.mydailyprogress.tracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mydailyprogress.tracker.data.local.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getInstance(application).appDao()
    private val settingsStore = SettingsDataStore(application)

    init {
        viewModelScope.launch {
            AppDatabase.seedDefaultHabits(dao)
        }
    }

    val habits: StateFlow<List<HabitEntity>> = dao.observeHabits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habitLogs: StateFlow<List<HabitLogEntity>> = dao.observeAllHabitLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studySessions: StateFlow<List<StudySessionEntity>> = dao.observeStudySessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fitnessLogs: StateFlow<List<FitnessLogEntity>> = dao.observeFitnessLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val journals: StateFlow<List<JournalEntity>> = dao.observeJournals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val preferences: StateFlow<UserPreferences> = settingsStore.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    fun toggleHabitStatus(habitId: Long, dateStr: String, currentStatus: String?) {
        viewModelScope.launch {
            when (currentStatus) {
                null -> dao.upsertHabitLog(HabitLogEntity(habitId, dateStr, "COMPLETED"))
                "COMPLETED" -> dao.upsertHabitLog(HabitLogEntity(habitId, dateStr, "MISSED"))
                else -> dao.deleteHabitLog(habitId, dateStr)
            }
        }
    }

    fun saveHabit(titleEn: String, titleHi: String, category: String, scheduleType: String, reminderTime: String) {
        viewModelScope.launch {
            dao.upsertHabit(
                HabitEntity(
                    titleEn = titleEn,
                    titleHi = titleHi.ifBlank { titleEn },
                    category = category,
                    scheduleType = scheduleType,
                    customDaysCsv = "0,1,2,3,4,5,6",
                    reminderTime = reminderTime,
                    createdAtEpochDay = LocalDate.now().toEpochDay()
                )
            )
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch { dao.deleteHabit(habit) }
    }

    fun logStudySession(exam: String, subject: String, durationMinutes: Int, notes: String) {
        viewModelScope.launch {
            dao.insertStudySession(
                StudySessionEntity(
                    dateStr = LocalDate.now().toString(),
                    examType = exam,
                    subject = subject,
                    durationMinutes = durationMinutes,
                    notes = notes
                )
            )
        }
    }

    fun saveDailyFitness(weightKg: Float, workoutsCsv: String, proteinG: Int, waterMl: Int, notes: String) {
        viewModelScope.launch {
            dao.upsertFitnessLog(
                FitnessLogEntity(
                    dateStr = LocalDate.now().toString(),
                    bodyWeightKg = weightKg,
                    completedWorkoutsCsv = workoutsCsv,
                    proteinGrams = proteinG,
                    waterMl = waterMl,
                    notes = notes
                )
            )
        }
    }

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { settingsStore.setDarkMode(enabled) }
    }

    fun setLanguage(code: String) {
        viewModelScope.launch { settingsStore.setLanguage(code) }
    }

    fun setTargetWeight(weightKg: Float) {
        viewModelScope.launch { settingsStore.setTargetWeight(weightKg) }
    }

    fun setActiveExam(exam: String) {
        viewModelScope.launch { settingsStore.setActiveExam(exam) }
    }

    fun resetStatistics() {
        viewModelScope.launch { dao.clearAllHabitLogs() }
    }
}
