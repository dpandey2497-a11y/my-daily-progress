package com.mydailyprogress.tracker.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderScheduler.scheduleDailyReminder(
                context = context,
                reminderId = 1001,
                hour = 5,
                minute = 0,
                title = "My Daily Progress",
                message = "Good morning! Start your early morning routine and study plan."
            )
        }
    }
}
